#include "robot_select_init.h"

/* 全局机器人参数实例 */
Robot_Parament_InitTypeDef Robot_Parament;

/**************************************************************************
 * 功能: 固定为 LLS 麦轮车型，不读取电位器档位
 *
 * 实车: 528 霍尔麦轮电机
 *   - 11 线/圈, 减速比 131, TIM 四倍频 -> 5764 脉冲/圈
 *   - 轮距 210mm, 轴距 195mm, 轮径 97mm
 **************************************************************************/
void Robot_Select(void)
{
  Car_Mode = Mec_Car;
  Robot_Init(MEC_wheelspacing, MEC_axlespacing, 0.0f,
             (float)HALL_131, (float)Hall_11, Mecanum_97);
}

/**************************************************************************
 * 功能: 写入轮距/轴距/减速比/线数/轮径，并计算编码器精度与轮周长
 *
 * 输入:
 *   wheelspacing      - 半轮距 (m)
 *   axlespacing       - 半轴距 (m)
 *   omni_turn_radiaus - 全向轮转弯半径，麦轮为 0
 *   gearratio         - 减速比 (528 电机为 131)
 *   accuracy          - 霍尔线数 (528 电机为 11)
 *   tyre_diameter     - 轮径 (m)，97mm 轮为 0.097
 **************************************************************************/
void Robot_Init(double wheelspacing, float axlespacing, float omni_turn_radiaus,
                float gearratio, float accuracy, float tyre_diameter)
{
  Robot_Parament.WheelSpacing = wheelspacing;
  Robot_Parament.AxleSpacing = axlespacing;
  Robot_Parament.OmniTurnRadiaus = omni_turn_radiaus;
  Robot_Parament.GearRatio = (int)gearratio;
  Robot_Parament.EncoderAccuracy = (int)accuracy;
  Robot_Parament.WheelDiameter = tyre_diameter;

  /* 电机转一圈对应的编码器计数 */
  Encoder_precision = EncoderMultiples * Robot_Parament.EncoderAccuracy
                      * Robot_Parament.GearRatio;

  Wheel_perimeter = Robot_Parament.WheelDiameter * PI;

  Wheel_spacing = Robot_Parament.WheelSpacing;
  Axle_spacing = Robot_Parament.AxleSpacing;
  Omni_turn_radiaus = Robot_Parament.OmniTurnRadiaus;
}
