#ifndef __ROBOTSELECTINIT_H
#define __ROBOTSELECTINIT_H

#include "sys.h"
#include "system.h"

/* 机器人几何与电机参数结构体 */
typedef struct
{
  float WheelSpacing;    /* 半轮距 (m)，麦轮填左右轮中心距的一半 */
  float AxleSpacing;     /* 半轴距 (m)，麦轮填前后轮中心距的一半 */
  int GearRatio;         /* 电机减速比 */
  int EncoderAccuracy;   /* 电机霍尔线数 (线/圈) */
  float WheelDiameter;   /* 驱动轮直径 (m) */
  float OmniTurnRadiaus; /* 全向轮转弯半径，麦轮填 0 */
} Robot_Parament_InitTypeDef;

/* 四路编码器原始计数 */
typedef struct
{
  int A;
  int B;
  int C;
  int D;
} Encoder;

/* -------- LLS 校园巡检车实车参数 (528 麦轮电机) -------- */
/* 全宽 210mm / 全轴距 195mm -> 固件填半值 */
#define MEC_wheelspacing    0.105f
#define MEC_axlespacing     0.0975f

/* 528 电机: 11 线霍尔, 减速比 131:1 */
#define HALL_131            131
#define Hall_11             11

/* 麦轮直径 97mm */
#define Mecanum_97          0.097f

/* TIM 编码器四倍频: 每圈计数 = 4 * 11 * 131 = 5764 */
#define EncoderMultiples    4

/* 速度环与编码器采样频率 (Hz)，与 balance 任务一致 */
#define CONTROL_FREQUENCY   100

/* 阿克曼最小转弯半径 (m)，供 usartx.c 中 Vz_to_Akm_Angle() 编译；LLS 麦轮不用 */
#define MINI_AKM_MIN_TURN_RADIUS  0.35f

void Robot_Select(void);
void Robot_Init(double wheelspacing, float axlespacing, float omni_turn_radiaus,
                float gearratio, float accuracy, float tyre_diameter);

#endif
