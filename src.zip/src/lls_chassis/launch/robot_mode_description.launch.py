import os
import yaml
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

try:
    from xacro import process_file as xacro_process_file
except ImportError:
    xacro_process_file = None


def load_yaml(file_path: Path) -> dict:
    with open(file_path, 'r') as f:
        return yaml.safe_load(f)


def load_robot_description(xacro_path: str) -> str:
    if xacro_process_file is not None:
        return xacro_process_file(xacro_path).toxml()
    with open(xacro_path, 'r', encoding='utf-8') as f:
        return f.read()


def spawn_robot_nodes(context, *args, **kwargs):
    param_file = LaunchConfiguration('LLS_param_yaml').perform(context)
    robot_model_file = LaunchConfiguration('robot_model_yaml').perform(context)
    cfg = load_yaml(Path(param_file))
    model_cfg = load_yaml(Path(robot_model_file))

    car_mode = LaunchConfiguration('car_mode').perform(context) or cfg['car_mode']
    print(f'car_mode:{car_mode}')
    if car_mode not in model_cfg['robot_model']:
        raise ValueError(f'Unknown car_mode "{car_mode}" in {param_file}')

    model_cfg = model_cfg['robot_model'][car_mode]

    desc_pkg = get_package_share_directory('lls_description')
    xacro_file = os.path.join(desc_pkg, 'urdf', 'lls_patrol.urdf.xacro')
    robot_description = load_robot_description(xacro_file)

    # lls_patrol.urdf.xacro 已含 base_link / laser_link / gyro_link / camera_link，
    # 勿再发布同名 static TF（会与 robot_state_publisher 冲突导致建图失败）。
    return [
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': robot_description}],
        ),
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_to_radar',
            arguments=[*map(str, model_cfg['base_to_radar']), 'base_footprint', 'radar'],
        ),
    ]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            'LLS_param_yaml',
            default_value=os.path.join(
                get_package_share_directory('lls_chassis'),
                'config', 'lls_param.yaml'),
            description='Path to lls_param.yaml'),
        DeclareLaunchArgument(
            'robot_model_yaml',
            default_value=os.path.join(
                get_package_share_directory('lls_chassis'),
                'config', 'robot_model.yaml'),
            description='Path to robot_model.yaml'),
        DeclareLaunchArgument(
            'car_mode',
            default_value='',
            description='Which robot mode to launch (mini_akm, mini_mec...)'),
        OpaqueFunction(function=spawn_robot_nodes),
    ])
