import os
import yaml
from pathlib import Path
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch.actions import GroupAction, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory


# -------------------------------------------------
# 工具函数：读取 yaml
# -------------------------------------------------
def load_yaml(file_path: str) -> dict:
    return yaml.safe_load(Path(file_path).read_text())


# -------------------------------------------------
# 根据 imu_mode 生成节点列表
# -------------------------------------------------
def include_imu_launch(context, *args, **kwargs):
    # 1) 读取默认 imu_mode（yaml 中）
    cfg_path = LaunchConfiguration('imu_mode_yaml').perform(context)
    cfg = load_yaml(cfg_path)
    imu_mode = LaunchConfiguration('imu_mode').perform(context) or cfg['imu_mode']
    print(f'imu_mode:{imu_mode}')

    parm_file = LaunchConfiguration('LLS_param_yaml').perform(context)
    car_cfg = load_yaml(parm_file)
    car_mode = LaunchConfiguration('car_mode').perform(context) or car_cfg['car_mode']
    ranger_avoid_flag = LaunchConfiguration('ranger_avoid_flag').perform(context) or car_cfg['ranger_avoid_flag']
    
    # 公共参数
    common_params = {
        'usart_port_name': car_cfg.get('chassis_port', '/dev/lls_chassis'),
        'serial_baud_rate': 115200,
        'robot_frame_id': 'base_footprint',
        'odom_frame_id': 'odom_combined',
        'gyro_frame_id': 'gyro_link',
        'cmd_vel': 'cmd_vel',
        'akm_cmd_vel': 'none',
        'product_number': 0,
        'odom_x_scale': 1.0,
        'odom_y_scale': 1.0,
        'odom_z_scale_positive': 1.0,
        'odom_z_scale_negative': 1.0,
        'car_mode': car_mode,
        'ranger_avoid_flag': ranger_avoid_flag
    }

    nodes = []
    remappings=[('imu/data_raw', 'imu/data_board')]
    # LLS 主节点
    if imu_mode == 'stm32':
        remappings = []
        
    LLS_node = Node(
        package='lls_chassis',
        executable='lls_chassis_node',
        output='screen',
        parameters=[common_params],
        remappings=remappings,
    )
    nodes.append(LLS_node)
    if imu_mode == 'stm32':
        remappings = []
    elif imu_mode == 'H30':
        nodes.append(
                    IncludeLaunchDescription(
                        PythonLaunchDescriptionSource([
                            os.path.join(
                                get_package_share_directory('yesense_std_ros2'),
                                'launch',
                                'yesense_node.launch.py'
                            )
                        ])
                    )
            )

    else:
        raise ValueError(f'Unsupported imu_mode: {imu_mode}')
    return nodes


# -------------------------------------------------
# 主入口
# -------------------------------------------------
def generate_launch_description():

    # 2) 声明可覆盖的参数
    declare_imu_path = DeclareLaunchArgument(
        'imu_mode_yaml',
        default_value=os.path.join(
        get_package_share_directory('lls_chassis'),
        'config', 'lls_param.yaml'
        ),
        description='Path to imu_mode.yaml'
    )
    declare_imu_mode = DeclareLaunchArgument(
        'imu_mode',
        default_value='',
        description='stm32 or H30'
    )

    declare_carparam_mode = DeclareLaunchArgument(
        'LLS_param_yaml',
        default_value=os.path.join(
            get_package_share_directory('lls_chassis'),
            'config', 'lls_param.yaml'),
        description='Path to lls_param.yaml'
    )
    # 添加 car_mode 的声明
    declare_car_mode = DeclareLaunchArgument(
        'car_mode',
        default_value='',
        description='Car mode configuration'
    )

    declare_ranger = DeclareLaunchArgument(
        'ranger_avoid_flag',
        default_value='',
        description='Whether to enable ranger avoidance'
    )

    # 3) 使用 OpaqueFunction 在运行时生成节点
    return LaunchDescription([
        declare_imu_path,
        declare_imu_mode,
        declare_carparam_mode,
        declare_car_mode,
        declare_ranger,
        OpaqueFunction(function=include_imu_launch)
    ])
