﻿"""
仅启动 slam_toolbox 异步建图节点。

前置条件（需另开终端或 launch 已启动）:
  - /scan  激光雷达
  - /odom  里程计
  - TF: odom -> base_link, base_link -> laser_link
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')
    default_slam_params = os.path.join(
        get_package_share_directory('lls_slam'),
        'config',
        'mapper_params_online_async.yaml',
    )
    slam_params_file = LaunchConfiguration(
        'slam_params_file',
        default=default_slam_params)

    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation clock if true'),

        DeclareLaunchArgument(
            'slam_params_file',
            default_value=slam_params_file,
            description='Full path to slam_toolbox parameter file'),

        Node(
            parameters=[slam_params_file, {'use_sim_time': use_sim_time}],
            package='slam_toolbox',
            executable='async_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
        ),
    ])
