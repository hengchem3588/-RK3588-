import os
import yaml
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    template_yaml = Path(
        get_package_share_directory('lslidar_driver'),
        'config',
        'lslidar_x10.yaml',
    )
    x10_cfg = yaml.safe_load(template_yaml.read_text())['x10']['lslidar_driver_node']['ros__parameters']

    return LaunchDescription([
        Node(
            package='lslidar_driver',
            executable='lslidar_driver_node',
            name='lslidar_driver_node',
            namespace='x10',
            parameters=[x10_cfg],
            output='screen',
        ),
    ])
