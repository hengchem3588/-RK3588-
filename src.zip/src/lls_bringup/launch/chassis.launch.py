"""C30D 底盘 + EKF（轮趣协议，/dev/lls_chassis）"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    chassis_dir = get_package_share_directory('lls_chassis')
    launch_dir = os.path.join(chassis_dir, 'launch')

    return LaunchDescription([
        DeclareLaunchArgument('carto_slam', default_value='false'),
        DeclareLaunchArgument('robot_nav', default_value='true'),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(launch_dir, 'base_serial.launch.py')),
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(launch_dir, 'wheeltec_ekf.launch.py')),
            launch_arguments={
                'carto_slam': LaunchConfiguration('carto_slam'),
                'robot_nav': LaunchConfiguration('robot_nav'),
            }.items(),
        ),
    ])
