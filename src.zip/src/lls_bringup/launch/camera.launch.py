"""
Aurora 930 深度相机（Deptrum ROS2 驱动）

话题（namespace=aurora）:
  /aurora/rgb/image_raw
  /aurora/depth/image_raw
  /aurora/points2
  TF: depth_camera_link

用法:
  ros2 launch lls_bringup camera.launch.py
  ros2 launch lls_bringup camera.launch.py use_rviz:=true
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
  deptrum_share = get_package_share_directory('deptrum-ros-driver-aurora930')

  return LaunchDescription([
    DeclareLaunchArgument('use_rviz', default_value='false'),
    DeclareLaunchArgument('rgb_fps', default_value='12'),
    DeclareLaunchArgument('ir_fps', default_value='12'),
    DeclareLaunchArgument('ir_enable', default_value='false'),
    DeclareLaunchArgument('point_cloud_enable', default_value='true'),

    IncludeLaunchDescription(
      PythonLaunchDescriptionSource(
        os.path.join(deptrum_share, 'launch', 'aurora930_launch.py'),
      ),
      launch_arguments={
        'rgb_enable': 'true',
        'depth_enable': 'true',
        'ir_enable': LaunchConfiguration('ir_enable'),
        'point_cloud_enable': LaunchConfiguration('point_cloud_enable'),
        'rgb_fps': LaunchConfiguration('rgb_fps'),
        'ir_fps': LaunchConfiguration('ir_fps'),
        'align_mode': 'true',
        'resolution_mode_index': '2',
      }.items(),
    ),

    IncludeLaunchDescription(
      PythonLaunchDescriptionSource(
        os.path.join(deptrum_share, 'launch', 'viewer930_launch.py'),
      ),
      condition=IfCondition(LaunchConfiguration('use_rviz')),
    ),
  ])
