"""
感知链路：Aurora 930 相机 + YOLOv8 RKNN 识别（demo）

用法（ELF2）:
  source install/setup.bash
  ros2 launch lls_bringup perception.launch.py

可选:
  ros2 launch lls_bringup perception.launch.py use_display:=true
  ros2 launch lls_bringup perception.launch.py detection_only:=true   # 相机已在别处启动
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, IncludeLaunchDescription
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
  bringup_dir = get_package_share_directory('lls_bringup')
  ws_root = os.path.abspath(os.path.join(bringup_dir, '..', '..', '..', '..'))
  demo_dir = os.path.join(ws_root, 'demo')
  demo_script = os.path.join(demo_dir, 'main_camera_fps_v8_with_info.py')

  model_default = os.path.join(demo_dir, 'rknnModel', 'best.rknn')
  detection_base = [
    'python3', demo_script,
    '--source', 'ros2',
    '--topic', '/aurora/rgb/image_raw',
    '--tpes', '4',
    '--model', model_default,
  ]

  return LaunchDescription([
    DeclareLaunchArgument('use_display', default_value='true'),
    DeclareLaunchArgument('detection_only', default_value='false'),

    IncludeLaunchDescription(
      PythonLaunchDescriptionSource(
        os.path.join(bringup_dir, 'launch', 'camera.launch.py'),
      ),
      condition=UnlessCondition(LaunchConfiguration('detection_only')),
    ),

    ExecuteProcess(
      cmd=detection_base + ['--no-display'],
      cwd=demo_dir,
      output='screen',
      condition=UnlessCondition(LaunchConfiguration('use_display')),
    ),

    ExecuteProcess(
      cmd=detection_base,
      cwd=demo_dir,
      output='screen',
      condition=IfCondition(LaunchConfiguration('use_display')),
    ),
  ])
