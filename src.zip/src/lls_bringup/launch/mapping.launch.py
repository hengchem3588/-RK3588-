﻿"""
建图一键启动（不含底盘/雷达驱动）:
  robot_state_publisher + slam_toolbox

建图完成后:
  ros2 launch lls_nav2 save_map.launch.py
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    desc_dir = get_package_share_directory('lls_description')
    slam_dir = get_package_share_directory('lls_slam')
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='false'),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(desc_dir, 'launch', 'description.launch.py')),
            launch_arguments={'use_sim_time': use_sim_time}.items(),
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(slam_dir, 'launch', 'lls_slam.launch.py')),
        ),
    ])
