﻿"""
自主导航一键启动（不含底盘/雷达驱动，需自行保证以下话题已发布）:
  /scan, /odom, /imu(可选), TF(odom->base_link->laser_link)

包含: robot_state_publisher + Nav2(AMCL+规划) + 航点巡逻节点
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    desc_dir = get_package_share_directory('lls_description')
    nav_dir = get_package_share_directory('lls_nav2')

    use_sim_time = LaunchConfiguration('use_sim_time', default='false')
    map_file = LaunchConfiguration(
        'map',
        default=os.path.join(nav_dir, 'map', 'campus_map.yaml'))
    params_file = LaunchConfiguration(
        'params',
        default=os.path.join(nav_dir, 'param', 'param_lls_mec.yaml'))

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='false'),
        DeclareLaunchArgument('map', default_value=map_file),
        DeclareLaunchArgument('params', default_value=params_file),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(desc_dir, 'launch', 'description.launch.py')),
            launch_arguments={'use_sim_time': use_sim_time}.items(),
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(nav_dir, 'launch', 'lls_nav2.launch.py')),
            launch_arguments={
                'use_sim_time': use_sim_time,
                'map': map_file,
                'params': params_file,
            }.items(),
        ),
    ])
