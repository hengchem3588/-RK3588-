"""
完整自主导航：底盘 + N10P + TF + Nav2 + 航点巡逻

前置：已保存地图 lls_nav2/map/campus_map.pgm

用法:
  ros2 launch lls_bringup navigation_full.launch.py
  RViz: 2D Pose Estimate 设初始位姿，Publish Point 点航点
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    bringup_dir = get_package_share_directory('lls_bringup')
    nav_dir = get_package_share_directory('lls_nav2')
    rviz_dir = get_package_share_directory('lls_rviz2')

    map_file = LaunchConfiguration(
        'map',
        default=os.path.join(nav_dir, 'map', 'campus_map.yaml'))
    params_file = LaunchConfiguration(
        'params',
        default=os.path.join(nav_dir, 'param', 'param_lls_mec.yaml'))

    return LaunchDescription([
        DeclareLaunchArgument('map', default_value=map_file),
        DeclareLaunchArgument('params', default_value=params_file),
        DeclareLaunchArgument('use_rviz', default_value='true'),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(bringup_dir, 'launch', 'chassis.launch.py')),
            launch_arguments={'robot_nav': 'true'}.items(),
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(bringup_dir, 'launch', 'lidar.launch.py')),
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(bringup_dir, 'launch', 'navigation.launch.py')),
            launch_arguments={
                'map': map_file,
                'params': params_file,
            }.items(),
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(rviz_dir, 'launch', 'lls_rviz_navigation.launch.py')),
            condition=IfCondition(LaunchConfiguration('use_rviz')),
        ),
    ])
