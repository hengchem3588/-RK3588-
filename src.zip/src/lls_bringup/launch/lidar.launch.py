"""N10P 激光雷达（lslidar_driver）"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource


def generate_launch_description():
    chassis_dir = get_package_share_directory('lls_chassis')
    return LaunchDescription([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(chassis_dir, 'launch', 'wheeltec_lidar.launch.py')),
        ),
    ])
