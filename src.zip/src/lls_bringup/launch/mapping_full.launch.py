"""
完整建图：底盘 + EKF + N10P + TF + slam_toolbox

与 RDK X5 轮趣流程对齐：先底盘/里程计，再雷达，再 URDF/TF，最后 SLAM。

用法:
  ros2 launch lls_bringup mapping_full.launch.py
  # 慢速遥控扫图后
  ros2 launch lls_nav2 save_map.launch.py
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    bringup_dir = get_package_share_directory('lls_bringup')
    desc_dir = get_package_share_directory('lls_description')
    slam_dir = get_package_share_directory('lls_slam')
    rviz_dir = get_package_share_directory('lls_rviz2')

    return LaunchDescription([
        DeclareLaunchArgument('carto_slam', default_value='false'),
        DeclareLaunchArgument('use_sim_time', default_value='false'),
        DeclareLaunchArgument('use_rviz', default_value='true'),

        # 1) 底盘串口 + EKF（发布 /odom、/imu/data_raw、odom_combined→base_footprint）
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(bringup_dir, 'launch', 'chassis.launch.py')),
            launch_arguments={
                'carto_slam': LaunchConfiguration('carto_slam'),
                'robot_nav': 'false',
            }.items(),
        ),

        # 2) N10P 雷达（/scan，frame_id=laser_link）
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(bringup_dir, 'launch', 'lidar.launch.py')),
        ),

        # 3) joint_state + robot_state（base_footprint→base_link→laser_link→gyro_link）
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(desc_dir, 'launch', 'description.launch.py')),
            launch_arguments={
                'use_sim_time': LaunchConfiguration('use_sim_time'),
            }.items(),
        ),

        # 4) slam_toolbox（发布 /map 与 map→odom_combined）
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(slam_dir, 'launch', 'lls_slam.launch.py')),
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(rviz_dir, 'launch', 'lls_rviz_mapping.launch.py')),
            condition=IfCondition(LaunchConfiguration('use_rviz')),
        ),
    ])
