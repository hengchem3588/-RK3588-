"""
LLS 校园安防巡逻 — 一键启动

启动顺序:
  1. 底盘 + EKF
  2. 激光雷达
  3. URDF/TF + Nav2 + AMCL
  4. Aurora 930 相机
  5. YOLO RKNN 检测（自动抓拍保存到 demo/img/）
  6. 看板服务器（端口 8888）
  7. 巡逻控制器

用法:
  ros2 launch lls_patrol patrol_full.launch.py
  ros2 launch lls_patrol patrol_full.launch.py use_rviz:=false
  ros2 launch lls_patrol patrol_full.launch.py use_camera:=false
  ros2 launch lls_patrol patrol_full.launch.py use_dashboard:=false
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    IncludeLaunchDescription,
)
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    bringup_dir = get_package_share_directory("lls_bringup")
    nav_dir = get_package_share_directory("lls_nav2")
    rviz_dir = get_package_share_directory("lls_rviz2")
    desc_dir = get_package_share_directory("lls_description")

    # 工作空间根目录
    ws_root = os.path.abspath(os.path.join(bringup_dir, "..", "..", "..", ".."))
    demo_dir = os.path.join(ws_root, "demo")
    pc_demo_dir = os.path.join(ws_root, "pc_demo")

    # 参数
    map_file = LaunchConfiguration("map", default=os.path.join(nav_dir, "map", "campus_map.yaml"))
    nav_params = LaunchConfiguration("params", default=os.path.join(nav_dir, "param", "param_lls_mec.yaml"))

    return LaunchDescription([
        # ═══════════════ 参数 ═══════════════
        DeclareLaunchArgument("map", default_value=map_file),
        DeclareLaunchArgument("params", default_value=nav_params),
        DeclareLaunchArgument("use_rviz", default_value="true"),
        DeclareLaunchArgument("use_camera", default_value="true"),
        DeclareLaunchArgument("use_display", default_value="true"),
        DeclareLaunchArgument("use_dashboard", default_value="true"),

        # ═══════════════ 1. 底盘 + EKF ═══════════════
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(bringup_dir, "launch", "chassis.launch.py")),
            launch_arguments={"robot_nav": "true", "carto_slam": "false"}.items(),
        ),

        # ═══════════════ 2. 激光雷达 ═══════════════
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(bringup_dir, "launch", "lidar.launch.py")),
        ),

        # ═══════════════ 3. URDF + Nav2 ═══════════════
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(desc_dir, "launch", "description.launch.py")),
            launch_arguments={"use_sim_time": "false"}.items(),
        ),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(nav_dir, "launch", "lls_nav2.launch.py")),
            launch_arguments={"map": map_file, "params": nav_params}.items(),
        ),

        # ═══════════════ 4. Aurora 930 ═══════════════
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(bringup_dir, "launch", "camera.launch.py")),
            condition=IfCondition(LaunchConfiguration("use_camera")),
        ),

        # ═══════════════ 5. YOLO 检测 ═══════════════
        ExecuteProcess(
            cmd=[
                "python3",
                os.path.join(demo_dir, "main_camera_fps_v8_with_info.py"),
                "--source", "ros2",
                "--topic", "/aurora/rgb/image_raw",
                "--tpes", "4",
                "--model", os.path.join(demo_dir, "rknnModel", "best.rknn"),
            ],
            cwd=demo_dir,
            output="screen",
            condition=IfCondition(LaunchConfiguration("use_display")),
        ),
        ExecuteProcess(
            cmd=[
                "python3",
                os.path.join(demo_dir, "main_camera_fps_v8_with_info.py"),
                "--source", "ros2",
                "--topic", "/aurora/rgb/image_raw",
                "--tpes", "4",
                "--model", os.path.join(demo_dir, "rknnModel", "best.rknn"),
                "--no-display",
            ],
            cwd=demo_dir,
            output="screen",
            condition=UnlessCondition(LaunchConfiguration("use_display")),
        ),

        # ═══════════════ 6. 看板 (端口 8888) ═══════════════
        ExecuteProcess(
            cmd=["python3", os.path.join(pc_demo_dir, "pc_demo_scanner.py")],
            cwd=pc_demo_dir,
            output="screen",
            condition=IfCondition(LaunchConfiguration("use_dashboard")),
        ),

        # ═══════════════ 7. 巡逻控制器 ═══════════════
        Node(
            package="lls_patrol",
            executable="patrol_controller",
            name="patrol_controller",
            output="screen",
        ),

        # ═══════════════ 8. RViz2 ═══════════════
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(rviz_dir, "launch", "lls_rviz_navigation.launch.py")),
            condition=IfCondition(LaunchConfiguration("use_rviz")),
        ),
    ])
