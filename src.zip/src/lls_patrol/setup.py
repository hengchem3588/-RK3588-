from setuptools import find_packages, setup

package_name = 'lls_patrol'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/patrol_full.launch.py']),
        ('share/' + package_name + '/config', ['config/patrol_config.yaml']),
        ('share/' + package_name + '/audio', [
            'audio/推搡.m4a',
            'audio/火焰.m4a',
            'audio/道路缺陷.m4a',
        ]),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='LLS Team',
    maintainer_email='hengchem3588@example.com',
    description='LLS Campus Security Patrol State Machine',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'patrol_controller = lls_patrol.patrol_controller:main',
        ],
    },
)
