"""
LLS 巡逻控制器
状态机: PATROL → STOPPING → ALERTING → NOTIFYING → WAITING → PATROL
检测和图像抓拍由 main_camera_fps_v8_with_info.py 的 DetectionLogger 处理
看板由 pc_demo_scanner.py 在 8888 端口提供
"""

import json
import os
import subprocess
import threading
import time
from typing import Any, Dict, List
from enum import Enum

import rclpy
import requests
from action_msgs.msg import GoalStatus
from geometry_msgs.msg import Twist
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from rclpy.node import Node
from std_msgs.msg import String


class PatrolState(Enum):
    PATROL = "PATROL"
    STOPPING = "STOPPING"
    ALERTING = "ALERTING"
    NOTIFYING = "NOTIFYING"
    WAITING = "WAITING"


class PatrolController(Node):
    def __init__(self):
        super().__init__("patrol_controller")

        # ── 加载配置 ──
        cfg = self._load_config()
        patrol_cfg = cfg.get("patrol", {})
        self.waypoints = patrol_cfg.get("waypoints", [])
        self.waypoint_pause = patrol_cfg.get("waypoint_pause", 2.0)

        alert_cfg = patrol_cfg.get("alert", {})
        self.alert_timeout = alert_cfg.get("timeout", 10.0)
        self.min_severity = alert_cfg.get("min_severity", 1)
        self.alert_classes = alert_cfg.get("alert_classes", [])

        alarm_cfg = patrol_cfg.get("alarm", {})
        self.alarm_volume = alarm_cfg.get("volume", 65)
        self.audio_map = alarm_cfg.get("audio_map", {})

        webhook_cfg = patrol_cfg.get("webhook", {})
        self.webhook_enabled = webhook_cfg.get("enabled", False)
        self.webhook_url = webhook_cfg.get("url", "")
        self.webhook_method = webhook_cfg.get("method", "json")

        # ── ROS2 接口 ──
        self._detection_sub = self.create_subscription(
            String, "/detection/info", self._on_detection, 10)
        self._cmd_vel_pub = self.create_publisher(Twist, "/cmd_vel", 10)

        # ── Nav2 action ──
        self._nav_client = ActionClient(self, NavigateToPose, "navigate_to_pose")
        self._goal_handle = None
        self._busy = False

        # ── 状态机 ──
        self._state = PatrolState.PATROL
        self._lock = threading.Lock()
        self._waypoint_idx = 0
        self._alert_data: Dict[str, Any] = {}
        self._alert_flag = False

        # ── 定时器 (10 Hz) ──
        self._timer = self.create_timer(0.1, self._state_machine)

        self._start_time = time.time()

        self.get_logger().info(
            f"巡逻控制器就绪 | 航点: {len(self.waypoints)} | "
            f"报警类别: {self.alert_classes or '全部'} | "
            f"音频映射: {list(self.audio_map.keys())} | "
            f"Webhook: {'已启用' if self.webhook_enabled else '未启用'} | "
            f"15 秒后开始巡逻"
        )

    # ── 配置 ──
    @staticmethod
    def _load_config():
        try:
            from ament_index_python.packages import get_package_share_directory
            import yaml
            path = os.path.join(get_package_share_directory("lls_patrol"), "config", "patrol_config.yaml")
            with open(path, encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {}

    # ── 检测回调 ──
    def _on_detection(self, msg: String):
        if self._state != PatrolState.PATROL:
            return
        try:
            data = json.loads(msg.data)
        except json.JSONDecodeError:
            return
        sev = data.get("severity", 0)
        cls_name = data.get("primary_class", "")
        if sev < self.min_severity:
            return
        if self.alert_classes and cls_name not in self.alert_classes:
            return
        self._alert_data = data
        self._alert_flag = True
        self.get_logger().warn(
            f"🚨 检测到 {cls_name} | 严重度={sev} | 数量={data.get('total_count', 0)}"
        )

    # ── 状态机 ──
    def _state_machine(self):
        if self._state == PatrolState.PATROL:
            self._run_patrol()
        elif self._state == PatrolState.STOPPING:
            self._run_stopping()
        elif self._state == PatrolState.ALERTING:
            self._run_alerting()
        elif self._state == PatrolState.NOTIFYING:
            self._run_notifying()
        elif self._state == PatrolState.WAITING:
            self._run_waiting()

    # ── PATROL ──
    def _run_patrol(self):
        if self._alert_flag:
            self._alert_flag = False
            self._transition(PatrolState.STOPPING)
            return
        if not self.waypoints:
            return
        if not self._nav_client.wait_for_server(timeout_sec=0.1):
            return
        if self._busy:
            return
        # 等 Nav2 完全就绪后再开始发航点（约 30 秒）
        if time.time() - self._start_time < 30.0:
            return

        wp = self.waypoints[self._waypoint_idx]
        self._send_goal(wp)

    def _send_goal(self, wp):
        import math
        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = "map"
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = wp["x"]
        goal.pose.pose.position.y = wp["y"]
        yaw = math.radians(wp.get("yaw_deg", 0.0))
        goal.pose.pose.orientation.z = math.sin(yaw / 2)
        goal.pose.pose.orientation.w = math.cos(yaw / 2)

        self.get_logger().info(f"航点 {self._waypoint_idx+1}: ({wp['x']:.1f}, {wp['y']:.1f})")
        future = self._nav_client.send_goal_async(goal)
        future.add_done_callback(self._on_goal_response)
        self._busy = True

    def _on_goal_response(self, future):
        gh = future.result()
        if gh and gh.accepted:
            self._goal_handle = gh
            result_future = gh.get_result_async()
            result_future.add_done_callback(self._on_result)
        else:
            self.get_logger().warn("目标被拒绝")
            self._busy = False
            self._waypoint_idx = (self._waypoint_idx + 1) % len(self.waypoints)

    def _on_result(self, future):
        result = future.result()
        self._goal_handle = None
        self._busy = False
        if result.status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info(f"到达航点 {self._waypoint_idx+1}")
        else:
            self.get_logger().warn(f"航点 {self._waypoint_idx+1} 失败")
        self._waypoint_idx = (self._waypoint_idx + 1) % len(self.waypoints)
        time.sleep(self.waypoint_pause)

    # ── STOPPING ──
    def _run_stopping(self):
        if self._goal_handle:
            self._nav_client._cancel_goal_async(self._goal_handle)
            self._goal_handle = None
        stop = Twist()
        for _ in range(30):
            self._cmd_vel_pub.publish(stop)
            time.sleep(0.02)
        self.get_logger().info("🛑 已停车")
        self._transition(PatrolState.ALERTING)

    # ── ALERTING ──
    def _run_alerting(self):
        cls_name = self._alert_data.get("primary_class", "")
        audio_rel = self.audio_map.get(cls_name, "")
        if audio_rel:
            from ament_index_python.packages import get_package_share_directory
            pkg_dir = get_package_share_directory("lls_patrol")
            path = os.path.join(pkg_dir, audio_rel)
            if os.path.exists(path):
                try:
                    subprocess.run(["amixer", "sset", "Speaker", f"{self.alarm_volume}%"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    for player in (["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"],
                                   ["aplay"], ["paplay"]):
                        try:
                            subprocess.run([*player, path], timeout=15)
                            break
                        except Exception:
                            continue
                    self.get_logger().info(f"🔊 播放报警: {audio_rel}")
                except Exception:
                    self.get_logger().warn("音频播放失败")
        else:
            self.get_logger().info(f"🔔 报警: {cls_name}")
        self._transition(PatrolState.NOTIFYING)

    # ── NOTIFYING ──
    def _run_notifying(self):
        if not self.webhook_enabled or not self.webhook_url:
            self.get_logger().info("Webhook 未启用")
            self._transition(PatrolState.WAITING)
            return

        cls_name = self._alert_data.get("primary_class", "?")
        sev = self._alert_data.get("severity", 0)
        count = self._alert_data.get("total_count", 0)
        labels = ["无", "低", "中", "高"]
        text = (
            f"🚨 LLS 安防警报\n"
            f"事件: {cls_name} | 严重程度: {labels[min(sev,3)]} | 数量: {count}\n"
            f"时间: {time.strftime('%H:%M:%S')}\n"
            f"看板: http://172.28.140.9:8888/"
        )
        try:
            if self.webhook_method == "json":
                resp = requests.post(self.webhook_url, json={"text": text}, timeout=5)
            else:
                resp = requests.post(self.webhook_url, data={"text": text}, timeout=5)
            self.get_logger().info(f"📤 通知已发送: {resp.status_code}")
        except Exception as e:
            self.get_logger().error(f"通知失败: {e}")
        self._transition(PatrolState.WAITING)

    # ── WAITING ──
    def _run_waiting(self):
        self.get_logger().info(f"⏳ 等待 {self.alert_timeout}s...")
        time.sleep(self.alert_timeout)
        self._alert_data = {}
        self.get_logger().info("▶ 恢复巡逻")
        self._transition(PatrolState.PATROL)

    # ── 辅助 ──
    def _transition(self, new_state: PatrolState):
        with self._lock:
            old = self._state
            self._state = new_state
        self.get_logger().info(f"状态: {old.value} → {new_state.value}")


def main():
    rclpy.init()
    node = PatrolController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
