"""
LLS 巡逻控制器
状态机: PATROL → STOPPING → ALERTING → NOTIFYING → WAITING → PATROL
"""

import json
import math
import os
import subprocess
import threading
import time
from typing import Any, Dict

import rclpy
from action_msgs.msg import GoalStatus
from geometry_msgs.msg import Twist
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from rclpy.node import Node
from std_msgs.msg import String


class PatrolState:
    PATROL = 0
    STOPPING = 1
    ALERTING = 2
    NOTIFYING = 3
    WAITING = 4


class PatrolController(Node):
    def __init__(self):
        super().__init__("patrol_controller")

        # ── 加载配置 ──
        cfg = self._load_config()
        p = cfg.get("patrol", {})

        self.waypoints = p.get("waypoints", [])
        self.waypoint_pause = p.get("waypoint_pause", 2.0)

        a = p.get("alert", {})
        self.alert_timeout = a.get("timeout", 10.0)
        self.min_severity = a.get("min_severity", 1)
        self.alert_classes = a.get("alert_classes", [])

        al = p.get("alarm", {})
        self.alarm_volume = al.get("volume", 65)
        self.audio_map = al.get("audio_map", {})

        wb = p.get("webhook", {})
        self.webhook_enabled = wb.get("enabled", False)
        self.webhook_url = wb.get("url", "")
        self.webhook_method = wb.get("method", "json")

        # ── 状态 ──
        self._state = PatrolState.PATROL
        self._state_enter_time = 0.0        # 进入当前状态的时间戳
        self._waypoint_idx = 0
        self._cooldown_until = 0.0

        # ── 检测数据 ──
        self._detection_msg: Dict[str, Any] = {}
        self._detection_flag = False

        # ── 报警状态内子步骤 ──
        self._stop_count = 0                # STOPPING 已停车次数
        self._alert_done = False            # ALERTING 是否已触发音频
        self._notify_done = False           # NOTIFYING 是否已发送
        self._wait_start = 0.0              # WAITING 开始时间

        # ── 导航 ──
        self._nav_client = ActionClient(self, NavigateToPose, "navigate_to_pose")
        self._goal_handle = None
        self._goal_active = False
        self._goal_pending = False          # 待重新发送目标

        # ── ROS2 接口 ──
        self._detection_sub = self.create_subscription(
            String, "/detection/info", self._on_detection, 10)
        self._cmd_vel_pub = self.create_publisher(Twist, "/cmd_vel", 10)

        # ── 非阻塞定时器 (20 Hz) ──
        self._timer = self.create_timer(0.05, self._state_machine)

        # 开机后 30 秒才开始巡逻（等 Nav2 完全启动）
        self._nav_ready_time = time.time() + 30.0

        if not self.waypoints:
            self.get_logger().warn("⚠ 航点列表为空！")

        self.get_logger().info(
            f"巡逻控制器就绪 | 航点: {len(self.waypoints)} | "
            f"报警类别: {self.alert_classes or '全部'} | "
            f"30 秒后开始巡逻"
        )

    # ═══════════════ 配置 ═══════════════
    @staticmethod
    def _load_config():
        try:
            from ament_index_python.packages import get_package_share_directory
            import yaml
            path = os.path.join(get_package_share_directory("lls_patrol"),
                                "config", "patrol_config.yaml")
            with open(path, encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {}

    # ═══════════════ 检测回调 ═══════════════
    def _on_detection(self, msg: String):
        if self._state != PatrolState.PATROL:
            return
        if time.time() < self._cooldown_until:
            return
        try:
            data = json.loads(msg.data)
        except json.JSONDecodeError:
            return
        sev = data.get("severity", 0)
        cls = data.get("primary_class", "")
        if sev < self.min_severity:
            return
        if self.alert_classes and cls not in self.alert_classes:
            return
        self._detection_msg = data
        self._detection_flag = True

    # ═══════════════ 状态机 (20 Hz, 非阻塞) ═══════════════
    def _state_machine(self):
        try:
            if self._state == PatrolState.PATROL:
                self._do_patrol()
            elif self._state == PatrolState.STOPPING:
                self._do_stopping()
            elif self._state == PatrolState.ALERTING:
                self._do_alerting()
            elif self._state == PatrolState.NOTIFYING:
                self._do_notifying()
            elif self._state == PatrolState.WAITING:
                self._do_waiting()
        except Exception as exc:
            self.get_logger().error(f"状态机异常: {exc}")

    def _enter(self, new_state: int, msg: str = ""):
        old = self._state
        self._state = new_state
        self._state_enter_time = time.time()
        names = {0: "PATROL", 1: "STOPPING", 2: "ALERTING", 3: "NOTIFYING", 4: "WAITING"}
        self.get_logger().info(
            f"{names[old]} → {names[new_state]}" + (f" | {msg}" if msg else ""))

    # ═══════════════ PATROL ═══════════════
    def _do_patrol(self):
        # 检测触发 → 转入 STOPPING
        if self._detection_flag:
            self._detection_flag = False
            self._stop_count = 0
            self._alert_done = False
            self._notify_done = False
            cls = self._detection_msg.get("primary_class", "?")
            self._enter(PatrolState.STOPPING,
                        f"🚨 {cls} sev={self._detection_msg.get('severity', 0)}")
            return

        if not self.waypoints or not self._nav_client.wait_for_server(timeout_sec=0.05):
            return
        if time.time() < self._nav_ready_time:
            return
        if self._goal_active:
            return

        # 待重新发送（从报警恢复后）
        if self._goal_pending:
            self._goal_pending = False
            time.sleep(0.5)  # 让 Nav2 消化取消操作

        self._send_goal(self.waypoints[self._waypoint_idx])

    def _send_goal(self, wp):
        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = "map"
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = wp["x"]
        goal.pose.pose.position.y = wp["y"]
        yaw = math.radians(wp.get("yaw_deg", 0.0))
        goal.pose.pose.orientation.z = math.sin(yaw / 2)
        goal.pose.pose.orientation.w = math.cos(yaw / 2)

        self.get_logger().info(f"航点 {self._waypoint_idx+1}: ({wp['x']:.1f}, {wp['y']:.1f})")
        self._nav_client.send_goal_async(goal).add_done_callback(self._on_goal_response)
        self._goal_active = True

    def _on_goal_response(self, future):
        gh = future.result()
        if gh and gh.accepted:
            self._goal_handle = gh
            gh.get_result_async().add_done_callback(self._on_result)
        else:
            self.get_logger().warn("目标被拒绝，跳过")
            self._goal_active = False
            self._waypoint_idx = (self._waypoint_idx + 1) % len(self.waypoints)

    def _on_result(self, future):
        self._goal_handle = None
        self._goal_active = False
        result = future.result()
        if result.status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info(f"到达航点 {self._waypoint_idx+1}")
        self._waypoint_idx = (self._waypoint_idx + 1) % len(self.waypoints)

    # ═══════════════ STOPPING ═══════════════
    def _do_stopping(self):
        # 取消当前导航
        if self._goal_handle:
            self._nav_client._cancel_goal_async(self._goal_handle)
            self._goal_handle = None
        self._goal_active = False
        self._goal_pending = True

        # 分 30 帧发零速（0.05s × 30 = 1.5s），不阻塞
        if self._stop_count < 30:
            self._cmd_vel_pub.publish(Twist())
            self._stop_count += 1
            return

        self.get_logger().info("🛑 已停车")
        self._enter(PatrolState.ALERTING)

    # ═══════════════ ALERTING ═══════════════
    def _do_alerting(self):
        if self._alert_done:
            self._enter(PatrolState.NOTIFYING)
            return
        self._alert_done = True
        self._play_alarm_async(self._detection_msg.get("primary_class", ""))

    def _play_alarm_async(self, cls_name: str):
        audio_rel = self.audio_map.get(cls_name, "")
        if not audio_rel:
            self.get_logger().info(f"🔔 {cls_name}（无匹配音频）")
            return
        try:
            from ament_index_python.packages import get_package_share_directory
            pkg_dir = get_package_share_directory("lls_patrol")
            path = os.path.join(pkg_dir, audio_rel)
            if not os.path.exists(path):
                return
            # 子线程播放，不阻塞主状态机
            def _play():
                subprocess.run(["amixer", "sset", "Speaker", f"{self.alarm_volume}%"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                for player in (["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"],
                               ["aplay"], ["paplay"]):
                    try:
                        subprocess.run([*player, path], timeout=15)
                        break
                    except Exception:
                        continue
            threading.Thread(target=_play, daemon=True).start()
            self.get_logger().info(f"🔊 {os.path.basename(audio_rel)}")
        except Exception:
            pass

    # ═══════════════ NOTIFYING ═══════════════
    def _do_notifying(self):
        if self._notify_done:
            self._wait_start = time.time()
            self._enter(PatrolState.WAITING)
            return
        self._notify_done = True
        self._send_webhook_async()

    def _send_webhook_async(self):
        if not self.webhook_enabled or not self.webhook_url:
            self.get_logger().info("Webhook 未启用")
            return
        cls = self._detection_msg.get("primary_class", "?")
        sev = self._detection_msg.get("severity", 0)
        labels = ["无", "低", "中", "高"]
        text = (f"🚨 LLS 安防警报\n事件: {cls} | 严重程度: {labels[min(sev,3)]}\n"
                f"数量: {self._detection_msg.get('total_count', 0)}\n"
                f"时间: {time.strftime('%H:%M:%S')}\n看板: http://172.28.140.9:8888/")
        def _send():
            try:
                import requests
                if self.webhook_method == "json":
                    requests.post(self.webhook_url, json={"text": text}, timeout=5)
                else:
                    requests.post(self.webhook_url, data={"text": text}, timeout=5)
                self.get_logger().info("📤 通知已发送")
            except Exception as e:
                self.get_logger().error(f"通知失败: {e}")
        threading.Thread(target=_send, daemon=True).start()

    # ═══════════════ WAITING ═══════════════
    def _do_waiting(self):
        elapsed = time.time() - self._wait_start
        if elapsed < self.alert_timeout:
            return  # 还在等待，啥都不做
        # 时间到，恢复
        self._detection_msg = {}
        self._cooldown_until = time.time() + 10.0
        self._enter(PatrolState.PATROL, f"继续前往航点 {self._waypoint_idx+1}")


def main():
    rclpy.init()
    node = PatrolController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
