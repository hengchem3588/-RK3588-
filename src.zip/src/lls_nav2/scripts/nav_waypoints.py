#!/usr/bin/env python3
"""读取 waypoints.yaml 并通过 Nav2 action 发送导航目标"""

import math
import os
import sys
import threading

import rclpy
import yaml
from action_msgs.msg import GoalStatus
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from rclpy.node import Node


class WaypointNavigator(Node):
    def __init__(self, waypoints_file: str):
        super().__init__("waypoint_navigator")

        with open(waypoints_file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        self.waypoints = data.get("waypoints", [])
        if not self.waypoints:
            self.get_logger().error("航点列表为空！")
            sys.exit(1)

        self._client = ActionClient(self, NavigateToPose, "navigate_to_pose")
        self._idx = 0
        self._busy = False
        self._goal_handle = None
        self.get_logger().info(f"加载了 {len(self.waypoints)} 个航点，等待 Nav2...")

        # 1Hz 定时器驱动状态机
        self._timer = self.create_timer(1.0, self._run)

    def _yaw(self, wp):
        if "yaw_deg" in wp:
            return math.radians(wp["yaw_deg"])
        return wp.get("yaw", 0.0)

    def _send_goal(self, wp):
        yaw = self._yaw(wp)
        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = "map"
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = wp["x"]
        goal.pose.pose.position.y = wp["y"]
        goal.pose.pose.orientation.z = math.sin(yaw / 2.0)
        goal.pose.pose.orientation.w = math.cos(yaw / 2.0)
        return goal

    def _on_goal_response(self, future):
        gh = future.result()
        if gh and gh.accepted:
            self._goal_handle = gh
            self._busy = True
            result_future = gh.get_result_async()
            result_future.add_done_callback(self._on_result)
        else:
            self.get_logger().warn("目标被拒绝，3 秒后重试")
            self._goal_handle = None
            threading.Timer(3.0, self._clear_busy).start()

    def _on_result(self, future):
        result = future.result()
        self._goal_handle = None
        self._busy = False
        if result.status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info(f"到达航点 {self._idx+1}")
        else:
            self.get_logger().warn(f"航点 {self._idx+1} 失败 (status={result.status})")
        self._idx = (self._idx + 1) % len(self.waypoints)

    def _clear_busy(self):
        self._busy = False
        self._idx = (self._idx + 1) % len(self.waypoints)

    def _run(self):
        if not self._client.wait_for_server(timeout_sec=0.5):
            return
        if self._busy:
            return

        wp = self.waypoints[self._idx]
        self.get_logger().info(
            f"航点 {self._idx+1}/{len(self.waypoints)}: ({wp['x']:.1f}, {wp['y']:.1f})"
        )
        goal = self._send_goal(wp)
        future = self._client.send_goal_async(goal)
        future.add_done_callback(self._on_goal_response)
        self._busy = True  # 防止重复发


def main():
    rclpy.init()
    try:
        from ament_index_python.packages import get_package_share_directory
        cfg = os.path.join(get_package_share_directory("lls_nav2"), "config", "waypoints.yaml")
    except Exception:
        cfg = os.path.join(os.path.dirname(__file__), "..", "config", "waypoints.yaml")
    if not os.path.exists(cfg):
        print(f"找不到航点文件: {cfg}")
        sys.exit(1)
    node = WaypointNavigator(cfg)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
