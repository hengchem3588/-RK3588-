﻿"""
启动 Nav2 自主导航（需已建图，且底盘/雷达/里程计节点已运行）。

用法:
  ros2 launch lls_nav2 lls_nav2.launch.py
  ros2 launch lls_nav2 lls_nav2.launch.py map:=/path/to/map.yaml
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')

    nav_dir = get_package_share_directory('lls_nav2')
    nav_launch_dir = os.path.join(nav_dir, 'launch')

    map_dir = os.path.join(nav_dir, 'map')
    map_file = LaunchConfiguration(
        'map',
        default=os.path.join(map_dir, 'campus_map.yaml'))

    param_dir = os.path.join(nav_dir, 'param')
    param_file = LaunchConfiguration(
        'params',
        default=os.path.join(param_dir, 'param_lls_mec.yaml'))

    return LaunchDescription([
        DeclareLaunchArgument(
            'map',
            default_value=map_file,
            description='Full path to map yaml file to load'),

        DeclareLaunchArgument(
            'params',
            default_value=param_file,
            description='Full path to Nav2 param file to load'),

        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation clock if true'),

        Node(
            name='waypoint_cycle',
            package='nav2_waypoint_cycle',
            executable='nav2_waypoint_cycle',
            output='screen',
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(nav_launch_dir, 'bringup_launch.py')),
            launch_arguments={
                'map': map_file,
                'use_sim_time': use_sim_time,
                'params_file': param_file,
                'slam': 'False',
            }.items(),
        ),
    ])
