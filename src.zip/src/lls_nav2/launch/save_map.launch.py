﻿"""
保存当前 slam_toolbox / map_server 发布的地图到 lls_nav2/map 目录。

用法（先 source 工作空间）:
  ros2 launch lls_nav2 save_map.launch.py
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    map_dir = os.path.join(
        get_package_share_directory('lls_nav2'), 'map')
    map_path = os.path.join(map_dir, 'campus_map')

    map_saver = Node(
        package='nav2_map_server',
        executable='map_saver_cli',
        output='screen',
        arguments=['-f', map_path],
        parameters=[
            {'save_map_timeout': 20000.0},
            {'free_thresh_default': 0.25},
            {'occupied_thresh_default': 0.65},
        ],
    )

    return LaunchDescription([map_saver])
