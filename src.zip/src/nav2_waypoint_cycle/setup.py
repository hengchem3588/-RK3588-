from setuptools import setup

package_name = 'nav2_waypoint_cycle'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='LLS Team',
    maintainer_email='lls@todo.todo',
    description='Nav2 waypoint patrol cycle node',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'nav2_waypoint_cycle = nav2_waypoint_cycle.waypoint_cycle:main'
        ],
    },
)
