﻿import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

try:
    from xacro import process_file as xacro_process_file
except ImportError:
    xacro_process_file = None


def load_robot_description(xacro_path: str) -> str:
    """用 Python xacro 展开 URDF，避免 shell 找不到 xacro 命令。"""
    if xacro_process_file is not None:
        return xacro_process_file(xacro_path).toxml()
    with open(xacro_path, 'r', encoding='utf-8') as f:
        return f.read()


def generate_launch_description():
    pkg = get_package_share_directory('lls_description')
    xacro_file = os.path.join(pkg, 'urdf', 'lls_patrol.urdf.xacro')
    robot_description = load_robot_description(xacro_file)

    use_sim_time = LaunchConfiguration('use_sim_time', default='false')

    # URDF 全是 fixed joint：必须发布 /joint_states，否则 robot_state_publisher
    # 不会发布 base_footprint→base_link→laser_link，雷达与 slam 都会失败。
    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation clock if true'),

        Node(
            package='joint_state_publisher',
            executable='joint_state_publisher',
            name='joint_state_publisher',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time}],
        ),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{
                'use_sim_time': use_sim_time,
                'robot_description': robot_description,
            }],
        ),
    ])
