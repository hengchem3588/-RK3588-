"""导航用 RViz：Fixed Frame = map，含 Nav2 面板与代价地图。"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource


def generate_launch_description():
    pkg_dir = get_package_share_directory('lls_rviz2')
    config = os.path.join(pkg_dir, 'rviz', 'lls_navigation.rviz')
    return LaunchDescription([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_dir, 'launch', 'lls_rviz.launch.py')),
            launch_arguments={'rviz_config': config}.items(),
        ),
    ])
